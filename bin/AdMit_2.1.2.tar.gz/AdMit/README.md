# AdMit
Adaptive Mixture of Student-t distributions.

[![DOI](https://zenodo.org/badge/59887530.svg)](https://zenodo.org/badge/latestdoi/59887530)
 	